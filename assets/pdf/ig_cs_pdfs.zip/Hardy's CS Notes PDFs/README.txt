:) GREETING !!! :)

The folder contains all the notes on IGCSE Computer Science that I've made since G1.
They cover all the theory knowledge (Chapter 1 - Chapter 6), 
except for sections 1.1 and 1.2 which mainly talk about binaries.
However, the notes don't cover algorithms and programing concepts which will be examined on Paper 2. 
Please make sure that you have revised it as well.

p.s. You can find out that the style of my notetaking is always changing... 
I believe the more recent notes are clearer :(

BTW, congratulations for enduring 22 months learning IG CS! 
There are only two months to the final exams. Believe that we can all make an A* in CS :) 

And I would like to thank Ms. Brown,
and all who has helped me with my journey on Computer Science throughout these months !

